/* bitrev.c - bit reverse of a B-bit integer n */

#include "bitrev.h"



