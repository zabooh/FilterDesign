#ifndef __DFTMERGE_H
#define __DFTMERGE_H

/* dftmerge.c - DFT merging for radix 2 decimation-in-time FFT */

#include "complex_float.h"



#endif
