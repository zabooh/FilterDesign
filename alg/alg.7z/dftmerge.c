/* dftmerge.c - DFT merging for radix 2 decimation-in-time FFT */

