#ifndef __SHUFFLE_H
#define __SHUFFLE_H

/* shuffle.c - in-place shuffling (bit-reversal) of a complex array */

#include "complex_float.h"



#endif 
