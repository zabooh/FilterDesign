#ifndef __SWAP_H
#define __SWAP_H

/*  swap.c  --  swap two complex numbers (by their addresses)  */

#include "complex_float.h"



#endif
