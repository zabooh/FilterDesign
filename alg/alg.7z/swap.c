/*  swap.c  --  swap two complex numbers (by their addresses)  */

#include "swap.h"
#include "complex_float.h"


