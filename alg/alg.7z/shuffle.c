/* shuffle.c - in-place shuffling (bit-reversal) of a complex array */


